package com.miguel.mybudgetplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybudgetplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybudgetplannerApplication.class, args);
	}

}
