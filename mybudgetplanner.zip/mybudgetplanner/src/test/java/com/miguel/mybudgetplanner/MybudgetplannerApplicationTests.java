package com.miguel.mybudgetplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybudgetplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
